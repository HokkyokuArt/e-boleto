package br.com.hjv.eboleto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EboletoApplicationTests {

	@Test
	void contextLoads() {
	}

}
